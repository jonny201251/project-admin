package com.haiying.project.model.vo;

import lombok.Data;

import java.util.List;

@Data
public class UploadVO {
    private List<TestVO> list;
}
