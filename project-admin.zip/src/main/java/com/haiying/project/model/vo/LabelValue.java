package com.haiying.project.model.vo;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class LabelValue {
    private Object label;
    private Object value;
}
