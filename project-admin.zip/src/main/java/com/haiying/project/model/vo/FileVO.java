package com.haiying.project.model.vo;

import lombok.Data;

@Data
public class FileVO {
    private String name;
    private String status;
    private String url;
}
