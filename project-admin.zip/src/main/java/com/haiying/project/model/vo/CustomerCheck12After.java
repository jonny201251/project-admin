package com.haiying.project.model.vo;

import com.haiying.project.model.entity.CustomerCheck12;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class CustomerCheck12After extends ProcessFormAfter {
    private CustomerCheck12 formValue;
}
