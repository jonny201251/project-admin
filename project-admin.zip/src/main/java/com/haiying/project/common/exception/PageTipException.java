package com.haiying.project.common.exception;

public class PageTipException extends RuntimeException{
    public PageTipException(String msg){
        super(msg);
    }
}
