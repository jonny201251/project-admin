package com.haiying.project.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.haiying.project.model.entity.SysDept;

/**
 * <p>
 * 部门 服务类
 * </p>
 *
 * @author 作者
 * @since 2022-02-15
 */
public interface SysDeptService extends IService<SysDept> {

}
