package com.haiying.project.service.impl;

import com.haiying.project.model.entity.Strategy;
import com.haiying.project.mapper.StrategyMapper;
import com.haiying.project.service.StrategyService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 战略伙伴信息 服务实现类
 * </p>
 *
 * @author 作者
 * @since 2022-03-25
 */
@Service
public class StrategyServiceImpl extends ServiceImpl<StrategyMapper, Strategy> implements StrategyService {

}
