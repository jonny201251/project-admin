package com.haiying.project.service;

import com.haiying.project.model.entity.CustomerScore2;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 客户信用评分2 服务类
 * </p>
 *
 * @author 作者
 * @since 2022-03-22
 */
public interface CustomerScore2Service extends IService<CustomerScore2> {

}
