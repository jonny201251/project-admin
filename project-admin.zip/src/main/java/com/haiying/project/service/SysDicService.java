package com.haiying.project.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.haiying.project.model.entity.SysDic;

/**
 * <p>
 * 数据字典 服务类
 * </p>
 *
 * @author 作者
 * @since 2021-12-27
 */
public interface SysDicService extends IService<SysDic> {

}
