package com.haiying.project.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.haiying.project.model.entity.ProcessInstNode;

/**
 * <p>
 * 流程实例节点 服务类
 * </p>
 *
 * @author 作者
 * @since 2022-02-14
 */
public interface ProcessInstNodeService extends IService<ProcessInstNode> {

}
