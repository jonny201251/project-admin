package com.haiying.project.service;

import com.haiying.project.model.entity.ProviderScore2;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 供方评分2 服务类
 * </p>
 *
 * @author 作者
 * @since 2022-03-17
 */
public interface ProviderScore2Service extends IService<ProviderScore2> {

}
