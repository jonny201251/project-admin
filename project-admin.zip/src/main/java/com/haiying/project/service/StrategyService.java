package com.haiying.project.service;

import com.haiying.project.model.entity.Strategy;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 战略伙伴信息 服务类
 * </p>
 *
 * @author 作者
 * @since 2022-03-25
 */
public interface StrategyService extends IService<Strategy> {

}
