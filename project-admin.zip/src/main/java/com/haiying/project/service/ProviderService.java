package com.haiying.project.service;

import com.haiying.project.model.entity.Provider;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 供方信息 服务类
 * </p>
 *
 * @author 作者
 * @since 2022-03-17
 */
public interface ProviderService extends IService<Provider> {

}
