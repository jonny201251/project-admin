package com.haiying.project.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.haiying.project.model.entity.SysRoleUser;

/**
 * <p>
 * 角色-用户 服务类
 * </p>
 *
 * @author 作者
 * @since 2022-02-24
 */
public interface SysRoleUserService extends IService<SysRoleUser> {

}
