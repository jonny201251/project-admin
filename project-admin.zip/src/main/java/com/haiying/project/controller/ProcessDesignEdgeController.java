package com.haiying.project.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 流程设计中的连线 前端控制器
 * </p>
 *
 * @author 作者
 * @since 2022-02-14
 */
@RestController
@RequestMapping("/process-design-edge")
public class ProcessDesignEdgeController {

}
