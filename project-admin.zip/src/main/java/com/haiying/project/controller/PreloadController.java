package com.haiying.project.controller;

import com.haiying.project.common.result.Wrapper;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/preload")
@Wrapper
public class PreloadController {

    @GetMapping("get")
    public Map<String, Object> get() {
        Map<String, Object> map = new HashMap<>();
        return map;
    }
}

