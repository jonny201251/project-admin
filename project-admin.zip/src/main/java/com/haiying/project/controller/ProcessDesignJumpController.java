package com.haiying.project.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 流程设计中的任务的跳转节点 前端控制器
 * </p>
 *
 * @author 作者
 * @since 2022-03-01
 */
@RestController
@RequestMapping("/process-design-jump")
public class ProcessDesignJumpController {

}
