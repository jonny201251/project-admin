package com.haiying.project.controller;

import com.haiying.project.common.result.Wrapper;
import com.haiying.project.model.entity.CustomerScore1;
import com.haiying.project.model.vo.UploadVO;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping
@Wrapper
public class Test {
    public static void main(String[] args) {
        CustomerScore1 formValue=new CustomerScore1();
        if(formValue.getVersion()>1){
            System.out.println("aa");
        }
    }
    @PostMapping("test")
    public boolean a(@RequestBody UploadVO uploadVO){
        System.out.println();
       return true;
    }
}
